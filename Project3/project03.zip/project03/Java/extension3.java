/**
 *Language Java: Extension 3:
 *Demonstrates the rules for identifier naming, variable
 *declarations and identifier scoping.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */

public class extension3 {


//declare a global variable to test its scope
int a_global = -1;
public extension3()
{
	
}

// try different symbols in the name of the identifier(_,.,/,^).
// the ones that is commented out are illegal
public int naming()
{
    int _a = 0;
    int abc = 1;
    int abc1 = 2;
    //int 1abc = 3;
    int a_bc1 = 4;
    //int a/bc = 5;
    //int #asd = 6;
    //int *sad = 7;
//    int s^a = 8;
//    int z&d = 9;
//    int @qq = 10;
//    int ..f = 11;
//    int ()g = 12;

    return 0;
}

// //declare a variable a twice in a function declaration.
public int declaration()
{
    int a = 13;
    System.out.println("first a "+a);
    //int a = 26;
    //System.out.println("second a "+a);
    return 0;
}

//test the scope for the identifier for a global variable, a variable in the block, 
//a variable in the function and a variable in the for loop.
public int scope()
{
    a_global++;
    System.out.println("Global: "+a_global);
    int a_function = 2;
    System.out.println("Function: "+a_function);
    int a_block = 10;
    if (true)
    {
        //int a_block= 5;
        System.out.println("Function: "+a_function);
        System.out.println("Block: "+a_block);
    }
    System.out.println("Block: "+a_block);
//    for(int i=0;i<2;i++) {
//        System.out.println("Outer: "+i);
//      for(int i=0;i<5;i++) {
//	    System.out.println("inner: "+i);
//      }
//    }
    for(int i=0;i<2;i++) {
        System.out.println("Outer: "+i);
      for(int j=0;j<5;j++) {
	    System.out.println("inner: "+j);
      }
    }

    return 0;     
}

public static void main(String[] args) {
	extension3 a = new extension3();
    System.out.println("Global: "+a.a_global);
    a.scope();
    System.out.println("Global: "+a.a_global);
   	//System.out.println("Function: "+a.a_function);
    a.declaration();
}

}
