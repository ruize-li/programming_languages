/**
 *Language C++: task 2:
 *Write a binary search on a list or array of numbers.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
#include <iostream> 
using namespace std; 

//the function use while loop to realize binary search  
int binarySearch(int arr[], int max,  int x) 
{ 
    int min = 0;
    while (min <= max) { 
        int m = (max + min) / 2; 
  
        if (arr[m] == x)
        { 
            return m; 
        }
  
        if (arr[m] < x) 
        {
            min = m + 1; 
        }
        else
        {
            max = m - 1;
        } 
    } 
    return -1; 
} 

int main(void) 
{ 
    int arr[] = { 1, 2, 3, 4, 5 };
    int x = 5; 
    int length = (sizeof(arr)/sizeof(arr[0]))-1;
    int result = binarySearch(arr, length, x); 
    if (result == -1)
    {
        std::cout << x << " doesn't exist\n";
    }
    else
    {
        std::cout << x << " exists at index " << result << "\n"; 
    }
                   
    return 0; 
} 
