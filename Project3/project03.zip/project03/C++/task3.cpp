/**
 *Language C++: task 3:
 *demonstrates all of the basic built-in types and how to construct aggregate types 
 *and which of the standard suite of operators (+-/*%) manipulate which types 
 *and what the resulting type of each operation is.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
#include <iostream> 
using namespace std; 



int main(void)
{
    int i = 0;
    
    //declared a variable in each of the data type and did some mathematical 
    //operations between them to see the resulting data type.
    struct A { int a; char b; bool c; float d; double e; void *f; wchar_t g;};
    struct A B = {.a = 1, .b = 'a', .c = true, .d = 1.2, .e = 1.11111, .f = &i, .g = 2345}; 
    std::cout << B.a << "\n";
    std::cout << B.b << "\n";
    std::cout << B.c << "\n";
    std::cout << B.d << "\n";
    std::cout << B.e << "\n";
    std::cout << B.f << "\n";
    std::cout << B.g << "\n";
    std::cout << "int-char " << typeid(B.a-B.b).name() << "\n";
    std::cout << "int-float " << typeid(B.a-B.d).name() << "\n";
    std::cout << "int-double " << typeid(B.a-B.e).name() << "\n";
    std::cout << "float-double " << typeid(B.d-B.e).name() << "\n";
    std::cout << "char-double " << typeid(B.b-B.e).name() << "\n";
    std::cout << "wchar_t-double " << typeid(B.g-B.e).name() << "\n";
    std::cout << "wchar_t-char " << typeid(B.g-B.b).name() << "\n";
    std::cout << "bool-char " << typeid(B.c-B.b).name() << "\n";

    

    return 0;
}

