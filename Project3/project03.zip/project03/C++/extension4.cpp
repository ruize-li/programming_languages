/**
 *Language C++: Extension 4:
 *Use built-in capability for binary search.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */


#include <bits/stdc++.h>  
using namespace std; 
  
int main() 
{ 
    vector<int> arr = {1, 2, 3, 4, 5, 6}; 
    int a = 5;
    //calls built in binary search method
    if (binary_search(arr.begin(), arr.end(), a)) 
       std::cout << a << " exists in vector"; 
    else 
       std::cout << a <<  " does not exist"; 
} 

