/**
 *Language C++: Extension 7:
 *Demonstrate whether functions are a basic data type in your language.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
#include <iostream> 
using namespace std; 

int f1()
{
    return 7;
}

void f2()
{
    std::cout << "NOTHING\n";
}
  
int main() 
{ 
	//make a variable hold a function.
    int a = f1();
    void b = f2();
} 
