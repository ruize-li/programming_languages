/**
 *Language C++: Extension 6:
 *Make a compilable and runnable haiku in the selected language.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */

#include <iostream> 
using namespace std; 

void haiku(int a = 1)
{    
    for (a = 0; a < 10 ; a++) {break;}
}
int main() {haiku(83 + 45);}


