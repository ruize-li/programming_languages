/**
 *Language C++: task1 : 
 *Demonstrates the rules for identifier naming, variable
 *declarations and identifier scoping. 
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
#include <iostream> 
using namespace std; 

//declare a global variable to test its scope
int a_global = -1;

// try different symbols in the name of the identifier(_,.,/,^).
// the ones that is commented out are illegal
 int naming()
 {
     int _a = 0;
     int abc = 1;
     int abc1 = 2;
     //int 1abc = 3;
     int a_bc1 = 4;
     //int a/bc = 5;
     //int #asd = 6;
    // int *sad = 7;
     //int s^a = 8;
     //int z&d = 9;
     //int @qq = 10;
     //int ..f = 11;
    // int ()g = 12;
 
     return 0;
 }
 
 //declare a variable a twice in a function declaration.
int declaration()
{
    int a = 13;
    std::cout << "First a: " << a << "\n";
    int a = 26;
    std::cout << "second a: " << a << "\n";
    return 0;
 }

//test the scope for the identifier for a global variable, a variable in the block, 
//a variable in the function and a variable in the for loop.
int scope()
{
    a_global++;
    std::cout << "Global: " << a_global << "\n";
    int a_function = 2;
    std::cout << "Function: " << a_function << "\n";
    int a_block = 10;
    if (1)
    {
        int a_block= 5;
        std::cout << "Function: " << a_function << "\n";
        std::cout << "Block: " << a_block << "\n";
    }
    std::cout << "Block: " << a_block << "\n"; 
    for(int i=0;i<2;i++) {
        std::cout << "for loop: outer" << i <<"\n";
      for(int i=0;i<5;i++) {
	    std::cout << "for loop: innerer" << i <<"\n";
      }
    }
    printf("\n");
    return 0;     
}

int main(void) 
{
    std::cout << "Global: " << a_global << "\n";
    scope();
    std::cout << "Global: " << a_global << "\n";
   // std::cout << "Function: " << a_function << "\n";
    declaration();
}
