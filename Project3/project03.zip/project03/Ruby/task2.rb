# /**
#  *Language Ruby: task 2:
#  *Write a binary search on a list or array of numbers.
#  *
#  *Cornelia (Zixuan) Wang
#  * 3/7/2019
#  */

#the function use while loop to realize binary search 
def binary_search(n, arr)
	
	middle = arr.length / 2
	i = 0
	j = arr.length - 1

	while i < j
		if arr[middle] == n
			return middle
		elsif arr[middle] > n
			j = middle - 1
			middle = (i + j) / 2
			puts "Bigger"
		else
			i = middle + 1
			middle = (i + j) / 2
			puts "Smaller"
		end
	end
  	return -1
end

a = [1,2,3,4,5]
b = 4
c = binary_search b, a
if c == -1
	puts "#{b} is not in the array"
else
	puts "#{b} is in the array at position #{c}"
end





