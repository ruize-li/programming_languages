# /**
#  *Language C++: task 3:
#  *demonstrates all of the basic built-in types and how to construct aggregate types 
#  *and which of the standard suite of operators (+-/*%) manipulate which types 
#  *and what the resulting type of each operation is.
#  *
#  *Cornelia (Zixuan) Wang
#  * 3/7/2019
#  */

#declared a variable in each of the data type and did some mathematical 
class Ss  
  def initialize()  
    @a = 1
    @b = 'hello world'
    @c = nil
    @d = :open
    @e = Array.new(5)
    @f = { "f1" => 80, "f2" => 100 }
    @g = 1.1
  end  
  
  def a  
    puts "#{@a}"  
  end 
   
  def b  
    puts "#{@b}"  
  end 
  
  def c 
    puts "#{@c}"  
  end 
  
  def d  
    puts "#{@d}"  
  end 
  
  def e  
    puts "#{@e}"  
  end
  
  def f  
    puts "#{@f}"  
  end 
  
  def g  
    puts "#{@g}"  
  end 
  
end 
#operations between them to see the resulting data type.
s = Ss.new() 
s.a
s.b
s.c
s.d
s.e
s.f
s.g

aa = 1
bb = 'hello world'
cc = nil
dd = :open
ee = Array.new(5)
ff = { "f1" => 80, "f2" => 100 }
gg = 1.1

r1 = aa-gg
if r1.instance_of? Float
    puts("true")
else
    puts("false")
end

r2 = aa-ee
if r2.instance_of? Float
    puts("true")
else
    puts("false")
end







