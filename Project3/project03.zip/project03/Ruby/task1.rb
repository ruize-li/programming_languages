# /**
#  *Language Ruby: task1 : 
#  *Demonstrates the rules for identifier naming, variable
#  *declarations and identifier scoping. 
#  *
#  *Cornelia (Zixuan) Wang
#  * 3/7/2019
#  */

#global = 3  #----> this won't work


def naming()
	_a = 0
	abc = 1
	abc1 = 2
	#1abc = 3
	a_bc1 = 4
    a/bc = 5
    #a#sd = 6
    *sad = 7
    s^a = 8
    z&d = 9
    @qq = 10
    #..f = 11
    #()g = 12
end	

# // try different symbols in the name of the identifier(_,.,/,^).
# // the ones that is commented out are illegal
def declaration()
	a = 13
    puts "First a #{a}"
    a = 26
    puts "Second a #{a}"
end

# //declare a variable a twice in a function declaration.
def scope()
	# global++
	# puts("global: #{global}")
    function = 2
    puts "function: #{function}"
    block = 10
    if (1)
    
        block= 5
        puts "function: #{function}"
        puts "block: #{block}"
    end
    
    puts "block: #{block}"
    for i in 1..3
    	puts "for loop outer #{i}"
  		for i in 1..3
    		puts "for loop inner #{i}"
  		end
	end
    puts "\n"
end
# puts "global: #{global}"
scope()
# puts "global: #{global}"
#puts "function: #{function}"
declaration()
    
    
    
