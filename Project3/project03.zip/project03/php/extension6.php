<!-- 
/**
 *Language php: Extension 6:
 *Make a compilable and runnable haiku in the selected language.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
 -->
<?php 
    
function haiku($a, $b, $c)
{
    return ($a+1)+($b-3)+$c+4;
}
echo haiku(1, 2, 3);

    
?>

 
