<!-- 
/**
 *Language php: task 2:
 *Write a binary search on a list or array of numbers.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
 -->
<?php 

//the function use while loop to realize binary search 
function binarySearch(Array $arr, $x) 
{ 
    if (count($arr) === 0) 
    return -1; 
    
    $low = 0; 
    $high = count($arr) - 1; 
      
    while ($low <= $high) { 
           
        $mid = floor(($low + $high) / 2); 
   
        if($arr[$mid] == $x) { 
            return $mid; 
        } 
  
        if ($x < $arr[$mid]) { 
            $high = $mid -1; 
        } 
        else {  
            $low = $mid + 1; 
        } 
    } 
      
    return -1; 
} 

$arr = array(1, 2, 3, 4, 5); 
$value = 5; 
$index = binarySearch($arr, $value);
if($index == -1) { 
	echo $value." Doesnt Exist\n";     
} 
else { 
     echo $value." Exists at index ",$index."\n";
}

?>
