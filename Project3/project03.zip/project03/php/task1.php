<!-- 
/**
 *Language php: task1 : 
 *Demonstrates the rules for identifier naming, variable
 *declarations and identifier scoping. 
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 -->
 
<?php

#declare a global variable to test its scope
$GLOBALS['a'] = 1;

#$global = -1;   #-----> won't work


// try different symbols in the name of the identifier(_,.,/,^).
// the ones that is commented out are illegal
function naming(){
    $_a = 0;
    $abc = 1;
    $abc1 = 2;
    //$1abc = 3;
    $a_bc1 = 4;
    //$a/bc = 5;
    $#asd = 6;
    $*sad = 7;
    //$s^a = 8;
    //$z&d = 9;
    $@qq = 10;
    //$..f = 11;
    //$()g = 12;
}

//declare a variable a twice in a function declaration.
function declaration(){
    $a = 13;
    echo "the value of a is", $a, "\n";
    $a = 26;
    echo "the value of a is", $a, "\n";
}

//test the scope for the identifier for a global variable, a variable in the block, 
//a variable in the function and a variable in the for loop.
function scope()
{
    $GLOBALS['a']++;
    echo "the value of global is", $GLOBALS['a'], "\n";
    $function = 2;
    echo "the value of function is", $function, "\n";
    $block = 10;
    if (true)
    {
        $block= 5;
        echo "the value of block is", $block, "\n";
        echo "the value of function is", $function, "\n";
    }
    echo "the value of block is", $block, "\n";
    for($i=0; $i<2; $i++) {
        echo "the value of outer for loop is", $i, "\n";
      for($i=0;$i<5;$i++) {
	    echo "the value of inner for loop is", $i, "\n";
      }
    }
    echo "\n"; 
}
  	echo "the value of global is ", $GLOBALS['a'], "\n";
    scope();
    echo "the value of global is",$GLOBALS['a'], "\n";
    echo "the value of function is", $function, "\n";
//     declaration();
?>