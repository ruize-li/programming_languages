<!-- 
/**
 *Language php: task 3:
 *demonstrates all of the basic built-in types and how to construct aggregate types 
 *and which of the standard suite of operators (+-/*%) manipulate which types 
 *and what the resulting type of each operation is.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
 -->
<?php 
class struct implements IteratorAggregate {

	//declared a variable in each of the data type and did some mathematical 
    public $a = "Hello world!";
    public $b = 5985;
    public $c = 10.365;
    public $d = true;
    public $e = array(1,2,3);
    public $f = null;
    
    public function __construct()
    {
      
    }
    
    
    public function getIterator() {
        return new ArrayIterator($this);
    }
    
}

$obj = new struct;

foreach($obj as $k => $v) {
    var_dump($k, $v);
    echo "\n";
}
//operations between them to see the resulting data type.
echo "double-int ",gettype($obj->c - $obj->b),"\n";
echo "int-bool ",gettype($obj->b - $obj->d),"\n";
echo "int-string ",gettype($obj->b - $obj->a),"\n";
echo "int-null ",gettype($obj->b - $obj->f),"\n";


?>
