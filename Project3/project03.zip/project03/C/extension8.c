/**
 *Language C: Extension 8
 * Make the stack be able to handle the overflow errors
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */


#include <stdio.h>
#include <stdlib.h>
#include "cstk.h"

//specify the capacity of the stack as a global variable 
int CSTK_MAX = 50;

//creates a stack with the size specified by the int value
Stack *stk_create(int size)
{	
	Stack *stk;
	stk = (Stack*)malloc(sizeof(Stack));
	stk->stack = (int*)malloc(sizeof(int)*size);
	stk->top = -1;
	return stk;

}

//recycles a stack
void stk_destroy (Stack* s)
{
	free(s->stack);
	free(s);
	
}

//adds a new value to the top of the stack
void stk_push(Stack* s, int value)
{
	this.stk_overflow(s);
	s->stack[++(s->top)] = value;
}

//removes a value from the top of the stack
int stk_pop(Stack* s)
{
	return s->stack[(s->top)--];
}

//prints out the list in the reverse order if the int value is 1, otherwise, 
//prints out in the original order
void stk_display(Stack* s, int value)
{
	if (value == 1)
	{
		for (int i = 0; i <= s->top; i++)
		{
			printf("%d\n", s->stack[i]);
		}
	}
	else
	{
		for (int i = s->top; i >= 0; i--)
		{
			printf("%d\n", s->stack[i]);
		}
	
	}
}
//the function that can double the size of the stack when it is full.
void stk_overflow(Stack* s)
{   
    int length = sizeof(s->stack)/sizeof(s->stack[0]);
    if (s->top == length-1)
    {
        Stack *a = stk_create(length*2);
        for (int i = 0; i < (s->top)+1 ; i++)
        {
            a->stack[i] = s->stack[i];
        }
        s = a;  
    }
}