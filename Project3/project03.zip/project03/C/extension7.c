/**
 *Language C: Extension 7:
 *Demonstrate whether functions are a basic data type in your language.
 *
 *Cornelia (Zixuan) Wang
 * 3/7/2019
 */
#include <stdio.h>

int f1()
{
    return 7;
}

void f2()
{
    printf("Nothing");
}

int main(int argc, char **argv)
{
	//make a variable hold a function.
    int a = f1();
    void b = f2();
}