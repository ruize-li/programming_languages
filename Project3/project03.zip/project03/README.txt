CS333 - Project #3 - README
Cornelia (Zixuan) Wang

Directory Layout:
project03/
|
|__/C/
|  |
|  |__/cstk.h
|  |__/cstk.c
|  |__/cstktest.c
|  |__/extension8.c
|
|__/php/
|  |
|  |__/task1.php
|  |__/task2.php
|  |__/task3.php
|  |__/extension6.php
|  |__/extension7.php
|
|__/C++/
|  |
|  |__/task1.cpp
|  |__/task2.cpp
|  |__/task3.cpp
|  |__/extension4.cpp
|  |__/extension6.cpp
|  |__/extension7.cpp
|
|__/Ruby/
|  |
|  |__/task1.rb
|  |__/task2.rb
|  |__/task3.rb
|
|__/Java/
|  |
|  |__/extension3.java


Run and build configuration for C:
OSX El Capitan 10.11.6 - Apple LLVM version 7.3.0 (clang-703.0.31)

Description for each subsection:
C:

  This is the C programming task. 

Task 1: create a header file that contains the necessary structures and the declarations of the member functions.
cstk.h
Since it's a header file, cannot compile/run.

Task 2:create a C file that includes the implementation of the member functions declared in the header file.
cstk.c
Since there is no main function, cannot compile/run

Task 3:Download cstktest.c. Compile and run it.

Compile:	gcc -o cstktest cstktest.c cstk.c
		
Run:		./cstktest

Output:		The original list: 0 1 2 3 4 5 6 7 8 9 
		The reversed list: 9 8 7 6 5 4 3 2 1 0 

Extension 7:Demonstrate whether functions are a basic data type in your language.

Compile:	gcc -o extension7 extension7.c 
		
Run:		./extension7

Output:		extension7.c:24:10: error: variable has incomplete type 'void'
    void b = f2();
         ^
There is an error generated, indicating that functions are not a basic data type in C.

Extension 8: Make the stack be able to handle the overflow errors
Extension8.c
Since there is no main function, cannot compile/run


PHP:
   This is the selected language programming task in PHP.

Task 1: Demonstrates the rules for identifier naming, variable declarations and identifier scoping.
 
compile&run 	php task1.php

Conclusion: 1.The naming rule: no number in the front, no ^, no .., no (), no$....
	    2.php doesn't assign memory space to the second a, but change the value for the variable a.
	    3.global variables have their scope in the file. Variables in a function have their scope inside the function. Variables in the block can shadow the ones outside the block. Variables in the inner for loop can shadow the ones inside the outer loop.

Task 2: Write a binary search on a list or array of numbers.
compile&run 	php task2.php
Output: 	5 Exists at index 4

Task 3: Demonstrates all of the basic built-in types and how to construct aggregate types and which of the standard suite of operators (+-/*%) manipulate which types and what the resulting type of each operation is.

compile&run 	php task3.php
Conclusion:	the resulting data type tends to be the one that takes up more memory between the two. Also, there is a warning when we did the operation on int and string, but it works out as an integer.

Extension 4:	Built-in capability for binary search.
There is no built in binary search function in php.

Extension 6: Make a compilable and runnable haiku in the selected language.

compile&run 	php extension6.php

Output		8

Extension 7:Demonstrate whether functions are a basic data type in your language.

compile&run 	php extension7.php
Output		NOTHING
This function is a basic data type in php.



C++:
   This is the selected language programming task in C++.

Task 1: Demonstrates the rules for identifier naming, variable declarations and identifier scoping.
 
compile		g++ -o task1 task1.cpp
run 		./task1	

Conclusion: 1.The naming rule: no number in the front, no ^, no .., no (), no$, no/, no #, no *, no @....
	    2. C++, there cannot be two declarations of variables with the same name.
	    3.global variables have their scope in the file. Variables in a function have their scope inside the function. Variables in the block cannot shadow the ones outside the block. Variables in the inner for loop cannot shadow the ones inside the outer loop.

Task 2: Write a binary search on a list or array of numbers.
compile		g++ -o task2 task2.cpp
run 		./task2	
Output: 	5 Exists at index 4

Task 3: Demonstrates all of the basic built-in types and how to construct aggregate types and which of the standard suite of operators (+-/*%) manipulate which types and what the resulting type of each operation is.

compile		g++ -o task3 task3.cpp
run 		./task3	
Conclusion:	the resulting data type tends to be the one that takes up more memory between the two. 

Extension 4:	Built-in capability for binary search.
compile		g++ -o extension4 extension4.cpp
run 		./extension4	
Output:		5 exists in vector

Extension 6: Make a compilable and runnable haiku in the selected language.

compile		g++ -o extension6 extension6.cpp
run 		./extension6	
Output		(should be empty)

Extension 7:Demonstrate whether functions are a basic data type in your language.

compile		g++ -o extension7 extension7.cpp
run 		./extension7	
Output		extension7.cpp:17:10: error: variable has incomplete type 'void'
    void b = f2();
         ^
1 error generated.
This function is a basic data type in php.
The program cannot compile, so a variable cannot hold an arbitrary function, function is not a basic data type in C++.


Extension 1: use additional language. Ruby is my third language.
RUBY:
   This is the selected language programming task in RUBY.

Task 1: Demonstrates the rules for identifier naming, variable declarations and identifier scoping.
 
compile&run 	ruby task1.rb

Conclusion: 1.The naming rule: no number in the front, no#, no .., no (), ....
	    2.ruby doesn't assign memory space to the second a, but change the value for the variable a.
	    3.global variables have limited scope. Variables in a function have their scope inside and outside the function. Variables in the block can shadow the ones outside the block. Variables in the inner for loop cannot shadow the ones inside the outer loop.

Task 2: Write a binary search on a list or array of numbers.
compile&run 	ruby task2.rb
Output: 	Smaller
		4 is in the array at position 3

Task 3: Demonstrates all of the basic built-in types and how to construct aggregate types and which of the standard suite of operators (+-/*%) manipulate which types and what the resulting type of each operation is.

compile&run 	ruby task3.rb
Output:		task3.rb:66:in `-': Array can't be coerced into Fixnum (TypeError)
	from task3.rb:66:in `<main>'
Conclusion:	There is an error generated. We can conclude that the operations can only happen between numbers but not with arrays.


Java:
This is the selected language programming task in Java.
Extension 3 :Develop explicit comparison code in, compare and contrast it with your selected languages.

Compile: javac extension3.java
Run:	 java extension3
Conclusion :1.The naming rule: no number in the front, no#, no .., no (),no /, no ^,no &, no @, no *...
	    2.Java there cannot be two declarations of variables with the same name.

	    3.global variables have the scope of the class. Variables in a function have their scope just inside the function. Variables in the block cannot shadow the ones outside the block, and there even cannot be a variable with the same name in the block. Variables in the inner for loop cannot shadow the ones inside the outer loop, the variable in the inner and outer loop cannot have the same name.

